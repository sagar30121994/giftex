// add base url
//  const String downloadurl = 'https://elasticbeanstalk-ap-south-1-877161406871.s3.ap-south-1.amazonaws.com/uploads/'; //development
const String baseUrl = //'https://giftex-uat-api.astaguru.com/WebApiModel/'; //development
    // 'https://api-uat.astaguru.com/WebApiModel/'; //development
    'https://api-uat.aws.giftex.in/WebApiModel/'; //development

// const String baseUrl =
//     'https://giftex-uat-api.astaguru.com/WebApiModel/'; //development
// const String CMSBaseurl = 'https://giftex-uat-api.astaguru.com/WebCMSApiModel/'; //development
const String CMSBaseurl = 'https://api-uat.aws.giftex.in/WebCMSApiModel/'; //development
const String notificationbaseUrl = 'https://giftex-uat-api.astaguru.com/'; //development

//final String baseUrl = '';  //production
// //
// final String baseUrl = 'http://localhost:3020/api/'; //development
// final String downloadurl = 'http://localhost:3020/uploads/'; //development
