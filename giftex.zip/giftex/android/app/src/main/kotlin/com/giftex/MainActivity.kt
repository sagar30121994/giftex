package com.giftex

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
